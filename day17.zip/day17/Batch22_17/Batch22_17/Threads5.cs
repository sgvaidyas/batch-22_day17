﻿using System;
using System.Threading;

namespace Batch22_17
{
    //delegate to the function that has one int parameter
    public delegate void Sumoffuncallback(int sum);

    class SumofNum
    {
        //num is to store val of n = 4  and sumcall to stoe instance of delegate that points to a function
        int num;
        Sumoffuncallback sumcall;
        //from main function 4 is n =num
        // callbackfun is pointing to printsum(int res) that is now assigned to sumcall
        public SumofNum(int n, Sumoffuncallback callbackfun)
        {
            num = n;
            sumcall = callbackfun;
        }
        public void getsum()
        {
            //num is already assigned in constructor(for ex 4)
            int sum = 0;
            for (int i = 0; i <= num; i++)
                sum += i;
            //sum = 10 that is passed to delegate => callback(10) => printsum(10)
            if (sumcall != null)
                sumcall(sum);
        }
    }
    class Threads5
    {
        public static void printsum(int res)
        {
            Console.WriteLine("the sum of all the natural num = "+res);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the num = ");
            int num = int.Parse(Console.ReadLine());

            Sumoffuncallback callback = new Sumoffuncallback(printsum);


            SumofNum ob = new SumofNum(num,callback);

            Thread t = new Thread(new ThreadStart(ob.getsum));
            t.Start();
        }
    }
}
