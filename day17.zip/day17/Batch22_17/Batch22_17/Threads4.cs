﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Batch22_17
{
    class SumOfOdd
    {
        /*
        public static void calsum(int num)
        {
            int sum = 0;
            for(int i=1;i<=num;i+=2)
            {
               sum += i;
            }
            Console.WriteLine("sum of odd num" + sum);
        }
        */
        public static void calsum(object num)
        {
            int sum = 0;
            int n = int.Parse(num.ToString());
            for (int i = 1; i <= n; i += 2)
            {
                sum += i;
            }
            Console.WriteLine("sum of odd num" + sum);
        }
    }
    class Threads4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the num = ");
            // int num = int.Parse(Console.ReadLine());
            object num = Console.ReadLine();

            // Thread t1 = new Thread(()=>SumOfOdd.calsum(num));

            ParameterizedThreadStart myparam = new ParameterizedThreadStart(SumOfOdd.calsum);


            Thread t1 = new Thread(myparam);
            t1.Start(num);
        }
    }
}
