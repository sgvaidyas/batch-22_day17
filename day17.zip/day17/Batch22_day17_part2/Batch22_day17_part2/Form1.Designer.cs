﻿namespace Batch22_day17_part2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblquestion1 = new System.Windows.Forms.Label();
            this.rb1a = new System.Windows.Forms.RadioButton();
            this.rb1b = new System.Windows.Forms.RadioButton();
            this.rb1c = new System.Windows.Forms.RadioButton();
            this.rb1d = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.btnstart = new System.Windows.Forms.Button();
            this.lbltimer = new System.Windows.Forms.Label();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnnext = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblquestion1
            // 
            this.lblquestion1.AutoSize = true;
            this.lblquestion1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquestion1.Location = new System.Drawing.Point(16, 87);
            this.lblquestion1.Name = "lblquestion1";
            this.lblquestion1.Size = new System.Drawing.Size(240, 20);
            this.lblquestion1.TabIndex = 0;
            this.lblquestion1.Text = "IS EDUCATION IMORTANT?";
            // 
            // rb1a
            // 
            this.rb1a.AutoSize = true;
            this.rb1a.Location = new System.Drawing.Point(20, 127);
            this.rb1a.Name = "rb1a";
            this.rb1a.Size = new System.Drawing.Size(46, 17);
            this.rb1a.TabIndex = 1;
            this.rb1a.TabStop = true;
            this.rb1a.Text = "YES";
            this.rb1a.UseVisualStyleBackColor = true;
            // 
            // rb1b
            // 
            this.rb1b.AutoSize = true;
            this.rb1b.Location = new System.Drawing.Point(20, 166);
            this.rb1b.Name = "rb1b";
            this.rb1b.Size = new System.Drawing.Size(41, 17);
            this.rb1b.TabIndex = 2;
            this.rb1b.TabStop = true;
            this.rb1b.Text = "NO";
            this.rb1b.UseVisualStyleBackColor = true;
            // 
            // rb1c
            // 
            this.rb1c.AutoSize = true;
            this.rb1c.Location = new System.Drawing.Point(20, 201);
            this.rb1c.Name = "rb1c";
            this.rb1c.Size = new System.Drawing.Size(65, 17);
            this.rb1c.TabIndex = 3;
            this.rb1c.TabStop = true;
            this.rb1c.Text = "MAY BE";
            this.rb1c.UseVisualStyleBackColor = true;
            // 
            // rb1d
            // 
            this.rb1d.AutoSize = true;
            this.rb1d.Location = new System.Drawing.Point(20, 246);
            this.rb1d.Name = "rb1d";
            this.rb1d.Size = new System.Drawing.Size(156, 17);
            this.rb1d.TabIndex = 4;
            this.rb1d.TabStop = true;
            this.rb1d.Text = "WHY SHOULD I ANSWER";
            this.rb1d.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblquestion1);
            this.panel1.Controls.Add(this.rb1d);
            this.panel1.Controls.Add(this.rb1a);
            this.panel1.Controls.Add(this.rb1c);
            this.panel1.Controls.Add(this.rb1b);
            this.panel1.Location = new System.Drawing.Point(28, 87);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 302);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.Controls.Add(this.radioButton4);
            this.panel2.Location = new System.Drawing.Point(411, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 302);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "WHAT DO YOU THINK OF SPORTS";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(20, 246);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(91, 17);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "MAY BE NOT";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(20, 127);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(94, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "INTERESTED";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(20, 201);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(65, 17);
            this.radioButton3.TabIndex = 3;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "MAY BE";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(20, 166);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(120, 17);
            this.radioButton4.TabIndex = 2;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "NOT INTERESTED";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // btnstart
            // 
            this.btnstart.Location = new System.Drawing.Point(28, 33);
            this.btnstart.Name = "btnstart";
            this.btnstart.Size = new System.Drawing.Size(75, 23);
            this.btnstart.TabIndex = 7;
            this.btnstart.Text = "START";
            this.btnstart.UseVisualStyleBackColor = true;
            this.btnstart.Click += new System.EventHandler(this.btnstart_Click);
            // 
            // lbltimer
            // 
            this.lbltimer.AutoSize = true;
            this.lbltimer.Location = new System.Drawing.Point(312, 33);
            this.lbltimer.Name = "lbltimer";
            this.lbltimer.Size = new System.Drawing.Size(47, 13);
            this.lbltimer.TabIndex = 8;
            this.lbltimer.Text = "TIMER=";
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(272, 415);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 9;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = true;
            // 
            // btnnext
            // 
            this.btnnext.Location = new System.Drawing.Point(411, 415);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(75, 23);
            this.btnnext.TabIndex = 10;
            this.btnnext.Text = "NEXT";
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.lbltimer);
            this.Controls.Add(this.btnstart);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblquestion1;
        private System.Windows.Forms.RadioButton rb1a;
        private System.Windows.Forms.RadioButton rb1b;
        private System.Windows.Forms.RadioButton rb1c;
        private System.Windows.Forms.RadioButton rb1d;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button btnstart;
        private System.Windows.Forms.Label lbltimer;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnnext;
    }
}

