﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch22_day17_part2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private int CountChar()
        {
            int count = 0;
            string file = @"C:\Users\User\Desktop\myfile.txt";
            using (StreamReader reader = new StreamReader(file))
            {
                string fullcontent = reader.ReadToEnd();
                count =  fullcontent.Length ;
                Thread.Sleep(3000);
            }
            return count;
        }
        private void btnreadme_Click(object sender, EventArgs e)
        {
            int count = 0;
            Thread t = new Thread(() => { count = CountChar(); });
            t.Start();

            lblinfo.Text = "Processing the file please wait";
            t.Join();
            lblinfo.Text = "No of char in file = "+ count.ToString();

        }
    }
}
