﻿using System;
using System.Threading;

namespace Batch22_17
{
    class Thread2
    {
        static void myfun()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + "   " + i);
                Thread.Sleep(1000);
            }
        }
        static void myfun1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + "   " + i);
                Thread.Sleep(500);
            }
        }
        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(myfun));
            t1.Name = "firstthread";
            Thread t2 = new Thread(new ThreadStart(myfun1));
            t2.Name = "second thread";

            t1.Start();
            t1.Join();
            t2.Start();
        }
    }
}
