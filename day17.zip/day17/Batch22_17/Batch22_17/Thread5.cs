﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Batch22_17
{
    class Myclass
    {
        public int num;
        public Myclass(int n)
        {
            num = n;
        }
        public void calsum()
        {
            int sum = 0;
            for (int i = 1; i <= num; i += 2)
            {
                sum += i;
            }
            Console.WriteLine("sum of odd num" + sum);
        }
    }
    class Thread5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the num = ");
            int num = int.Parse(Console.ReadLine());

            Myclass ob = new Myclass(num);

            Thread t = new Thread(new ThreadStart(ob.calsum));
            t.Start();
        }
    }
}
