﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Batch22_17
{
    class MyException:Exception
    {
        public MyException(string message):base(message)
        {

        }
    }
    class Customexception
    {
        static void checkmarks(int marks)
        {
            if(marks<85)
            {
                throw new MyException("sorry you have not cleared the assessment");
            }
        }
        static void Main(string[] args)
        {
            int marks;
            Console.WriteLine("Enter the assessment marks");
            marks = int.Parse(Console.ReadLine());

            try
            {
                checkmarks(marks);
                Console.WriteLine("you are selected");
            }
            catch(MyException ob)
            {
                Console.WriteLine(ob.Message);
            }
            finally
            {
                Console.WriteLine("i am executing ");
            }
            Console.WriteLine("Next section..............");
        }
    }
}
