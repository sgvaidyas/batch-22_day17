﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Batch22_day17_part2
{
    public partial class Form1 : Form
    {
        public int i;
        Thread threadtimer;

        public Form1()
        {
            InitializeComponent();
            i = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
        }

        private void waitAsec(object args)
        {
            for(;i<=5;i++)
            {
                lbltimer.Invoke((MethodInvoker)(() => lbltimer.Text = "TIMER = "+i.ToString()));
                Thread.Sleep(1000);
            }
            panel1.Invoke((MethodInvoker)delegate { panel1.Visible = false; });

            btnsubmit.Invoke((MethodInvoker)delegate { btnsubmit.Enabled = false; });

            btnnext.Invoke((MethodInvoker)delegate { btnnext.Enabled = true; });
           // btnnext.Enabled = true;
        }


        private void btnstart_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            btnnext.Enabled = false;
            threadtimer = new Thread(waitAsec);
            threadtimer.Start();
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
        }
    }
}
