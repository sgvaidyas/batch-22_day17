﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch22_day17_part2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private int CountChar()
        {
            int count = 0;
            string file = @"C:\Users\User\Desktop\myfile.txt";
            using (StreamReader reader = new StreamReader(file))
            {
                string fullcontent = reader.ReadToEnd();
                count = fullcontent.Length;
                Thread.Sleep(3000);
            }
            return count;
        }

        private async void btnreadme_Click(object sender, EventArgs e)
        {
            Task<int> task = new Task<int>(CountChar);
            task.Start();


            lblinfo.Text = "Processing data";
            int count = await task;

            lblinfo.Text = " no of char= " + count.ToString();


        }
    }
}
