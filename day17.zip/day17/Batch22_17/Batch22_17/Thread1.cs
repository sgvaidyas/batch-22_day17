﻿using System;
using System.Threading;

namespace Batch22_17
{
    class Thread1
    {
        static void Main(string[] args)
        {
            Thread t1 = Thread.CurrentThread;
            t1.Name = "Main";
            Console.WriteLine(t1.Name);
        }
    }
}
