﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Batch22_17
{
    class Factorial
    {
        public static void calfact()
        {
            Console.WriteLine("enter the num");
            int num = int.Parse(Console.ReadLine());
            int fact = 1;
            for(int i=1;i<=num;i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("the fact = "+fact);
        }
    }

    class Thread3
    {
        static void Main(string[] args)
        {
            Thread t1 = new Thread(delegate () { Factorial.calfact(); });
            //Thread t1 = new Thread(()=> Factorial.calfact());
            t1.Start();
            Console.WriteLine("this is a new line");
        }
    }
}
